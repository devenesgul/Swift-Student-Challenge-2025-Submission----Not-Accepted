

import SwiftUI

extension Color {
    
    static let myblue = Color("myblue")
    static let myblueDark = Color("myblueDark")
    
}
