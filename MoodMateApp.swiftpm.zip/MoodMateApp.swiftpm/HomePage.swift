
// Made with ❤️ by Enes Gül

import SwiftUI

@available(iOS 16.1, *)
struct HomePage: View {
    
    @State private var selectedMood: MoodDetailInfo? = nil
    @State private var navigateToDetail = false
    
    @State private var showHowItWorksPopup = false
    
    var body: some View {
        
        NavigationStack{
            
            GeometryReader { geometry in
            ZStack{
                
               Image("customBackground")
                    .resizable()
                    .ignoresSafeArea()
                    .frame(width: geometry.size.width, height: geometry.size.height)
                    
                VStack{
                    
                    Image("moodmatepng")
                        .padding(.bottom, 90)
                        .padding(.top, 200)
                    
                    
                    Text("How are you feeling today?")
                        .font(.system(size: 50))
                        .foregroundColor(.myblueDark)
                        .frame(maxWidth: .infinity, minHeight: 80)
                        .background(.white.opacity(0.7))
                        .fontWeight(.semibold)
                        .padding(.top, 80)
                        .fontDesign(.rounded)
                        
                    
                    
                    HStack{
                        
                        ForEach(allMoodsArray) { mood in
                            Button(action: {
                                selectedMood = mood
                            } ){
                                VStack{
                                    Text(mood.emoji)
                                        .font(.system(size: 40))
                                    
                                    Text(mood.name)
                                        .font(.caption)
                                        .foregroundColor(.black)
                                }
                                .frame(width: 90, height: 90)
                                .background(selectedMood?.name == mood.name ? Color.white.opacity(0.8) : Color.white.opacity(0.3))
                                .cornerRadius(20)
                            }
                        }
                    }
                    .padding()
                    
                  
                    VStack(spacing: 20){
                        
                        Button(action: {
                            if selectedMood != nil {
                                navigateToDetail = true
                            }
                        }){
                            Text("Next")
                                .font(.system(size: 35))
                                .fontWeight(.semibold)
                                .frame(width: 670, height: 80)
                                .background(Color.myblueDark)
                                .foregroundColor(.white)
                                .cornerRadius(20)
                                .fontDesign(.rounded)
                        }
                        .disabled(selectedMood == nil)
                    }
                    
        Spacer()
                    
                    Button(action: {
                        showHowItWorksPopup = true
                    }){
                        Text("How Can MoodMate Improve Your Day?")
                            .font(.system(size: 28))
                            .padding(35)
                            .foregroundColor(.myblueDark)
                            .fontWeight(.semibold)
                            .fontDesign(.rounded)
                    }
                    
                   
                    
                }
                .navigationDestination(isPresented: $navigateToDetail) {
                    if let selectedMood = selectedMood {
                        MoodDetailPage(mood: selectedMood)
                            .tint(Color.myblueDark)
                    }
                }
                
                Color.black.opacity(showHowItWorksPopup ? 0.5 : 0)
                        .ignoresSafeArea()
                        .onTapGesture {
                            showHowItWorksPopup = false
                        }
                
                
    // MARK: - Pop up view
                
                if showHowItWorksPopup {
                    VStack(spacing: 20) {
                        
                        ScrollView {

                                Text("Hello & Welcome to MoodMate 👋")
                                    .font(.system(size: 30))
                                    .fontWeight(.semibold)
                                    .padding(.horizontal, 30)
                                    .padding(.vertical, 30)
                                    .fontDesign(.rounded)
                            
                            
                            VStack(alignment: .leading){
                                Text("""
                                Let me introduce you to **MoodMate**!
                                
                                Everyone experiences their days differently, and our moods can change constantly. In these moments, people may feel or think in various ways. **That’s where MoodMate comes in!** 🎯 MoodMate is designed to uplift your day by offering motivation, personalized activities, and helpful suggestions tailored to your current mood.
                                """)
                                .font(.system(size: 22))
                                .padding(.horizontal, 30)
                                .fontDesign(.rounded)
                            }
                            
                            
                            VStack(alignment: .leading, spacing: 15){
                                Text("How It Works?")
                                    .font(.system(size: 30))
                                    .fontWeight(.semibold)
                                    .padding(.horizontal, 30)
                                    .padding(.top, 35)
                                    .fontDesign(.rounded)
                                
                                Text("""
                                1️⃣ **Answer the question:** "How are you feeling today?"
                                2️⃣ **Select the mood** that best represents your current state.
                                3️⃣ **Tap "Next"** to explore your mood-specific page.
                                """)
                                .font(.system(size: 22))
                                .padding(.horizontal, 30)
                                .fontDesign(.rounded)
                                    
                            }
                            
                            VStack(alignment: .leading, spacing: 15){
                                Text("What You’ll Find on Each Mood Page:")
                                    .font(.system(size: 30))
                                    .fontWeight(.semibold)
                                    .padding(.horizontal, 30)
                                    .padding(.top, 35)
                                    .fontDesign(.rounded)
                                
                                Text("""
                                🔹 **Quote** – A thoughtful quote to reflect your mood.
                                🔹 **Scientific Insight** – A brief explanation based on psychology and science.
                                🔹 **Indoor Activities** – Engaging things you can do at home.
                                🔹 **Outdoor Activities** – Fun suggestions to get you moving.
                                🔹 **Music Suggestions** (only for selected moods)
                                🔹 **Extra Advice** (only for selected moods)

                                Each mood page is **uniquely designed** with tailored recommendations and activities. Some sections allow you to **tap the "Change" button** to explore different quotes and activities.
                                """)
                                .font(.system(size: 22))
                                .padding(.horizontal, 30)
                                .fontDesign(.rounded)
                            }
                            
                            VStack(alignment: .leading, spacing: 15){
                                Text("Get a Challenge!")
                                    .font(.system(size: 30))
                                    .fontWeight(.semibold)
                                    .padding(.horizontal, 30)
                                    .padding(.top, 35)
                                    .fontDesign(.rounded)
                                
                                Text("""
                                At the bottom of each mood page, you’ll find a **“Get a Challenge”** button. 🎯

                                Tap it to receive a **simple, fun challenge** designed to brighten your day! If you’re not happy with the challenge, you can **tap the "Change" button** as many times as you like until you find one that suits you. 🔄
                                """)
                                .font(.system(size: 22))
                                .padding(.horizontal, 30)
                                .fontDesign(.rounded)
                            }
                            
                            Text("Enjoy MoodMate & make the most of your day!")
                                .font(.system(size: 30))
                                .fontWeight(.semibold)
                                .padding(.horizontal, 30)
                                .padding(.vertical, 30)
                                .fontDesign(.rounded)
                                .multilineTextAlignment(.center)
                            
                            Spacer()
                            
                        } // scrollView
                            
                            HStack {
                                
                                Button(action: {
                                    showHowItWorksPopup = false
                                }){
                                    Text("Close")
                                        .padding()
                                        .font(.system(size: 35))
                                        .fontWeight(.semibold)
                                        .frame(width: 500, height: 80)
                                        .background(Color.myblueDark)
                                        .foregroundColor(.white)
                                        .cornerRadius(20)
                                        .fontDesign(.rounded)
                                }
                            }
                            
                        
                        }
                        .padding()
                        .frame(maxWidth: 600, maxHeight: 800)
                        .background(Color.white)
                        .cornerRadius(20)
                        .shadow(radius: 10)
                        
                    
                } // Pop up

            } // ZStack
            .frame(width: geometry.size.width, height: geometry.size.height)
                
            }
            .ignoresSafeArea()
            
        }
        .tint(Color.myblueDark)
        
        
    } // Body
}
