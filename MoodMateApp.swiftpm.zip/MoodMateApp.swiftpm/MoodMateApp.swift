
// Made with ❤️ by Enes Gül

import SwiftUI

@available(iOS 16.1, *)
@main
struct MoodMateApp: App {
    var body: some Scene {
        WindowGroup {
            HomePage()
        }
    }
}
