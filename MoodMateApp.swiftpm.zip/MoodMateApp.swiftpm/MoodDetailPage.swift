

import SwiftUI

@available(iOS 16.1, *)
struct MoodDetailPage: View {
    
    let challenges = getAChallenge(challenges: [
        "Listen to music for 5 minutes 🎧🎶",
        "Write down three things you’re grateful for ✍️🙏📓",
        "Take a 15-minute walk outside 🚶‍♂️🌳",
        "Drink a full glass of water 🥤💧",
        "Try a deep breathing exercise for one minute 🌬️🧘‍♀️",
        "Stretch your body for five minutes 🧘‍♂️🤸‍♀️",
        "Read a few pages of a book 📖👓",
        "Draw or doodle something random 🎨🖍️",
        "Write a positive note to yourself ✍️💌",
        "Watch a short, funny video 🎬😂",
        "Take a break from your phone for 15 minutes 📱⏸️",
        "Organize a small part of your room or desk 🧹🗂️",
        "Try a simple meditation for a few minutes 🧘‍♂️🕯️",
        "Call or text a friend 📞💬",
        "Try a new type of music or podcast 🎶🎧",
        "Look at old photos that make you smile 📸😊",
        "Make a small plan or goal for the day 📝🎯",
        "Close your eyes and focus on your breathing 👀💆‍♂️",
        "Make a cup of tea or coffee and enjoy it slowly 🍵☕",
        "Step outside and feel the fresh air 🌤️🍃",
        "Compliment yourself on something you did well today 🌟💪",
        "Light a candle or use a relaxing scent 🕯️🌸",
        "Write down a small dream or idea you have 💭✍️",
        "Try a few minutes of light exercise or movement 🏃‍♀️💪",
        "Do nothing for one minute and just be present ⏱️🧘‍♀️"])
    
    @State var challengecurrentActivityIndex = 0
    @State private var showChallengeScreenPopUp = false

    
    let mood: MoodDetailInfo
    @State private var indoorcurrentActivityIndex = 0
    @State private var outdoorcurrentActivityIndex = 0
    @State private var quotecurrentActivityIndex = 0
    
    var body: some View{
        
        ZStack{
            Image("customBackground")
                .resizable()
                .ignoresSafeArea()
            
            
            ScrollView{
                VStack(spacing: 40){
                
                    VStack{
                        Text(mood.emoji)
                            .font(.system(size: 80))
                            .frame(width: 120, height: 120)
                            .background(Color.myblueDark.opacity(0.7))
                            .cornerRadius(20)
                        
                        Text("You're \(mood.name) today")
                            .font(.system(size: 35))
                            .fontWeight(.semibold)
                            .fontDesign(.rounded)
                            .foregroundColor(.myblueDark)
                            .multilineTextAlignment(.center)
                            .frame(width: 664)
                            .padding(.horizontal, 30)
                            .padding(.vertical, 30)
                            .background(Color.white.opacity(0.8))
                            .cornerRadius(20)            
                    }
               
                    
// MARK: - Quote
                    
                    
                    VStack(alignment: .leading){
                        HStack(alignment: .bottom){
                            Text("💬")
                                .font(.system(size: 60))
                                .frame(width: 90, height: 90)
                                .background(Color.myblueDark.opacity(0.7))
                                .cornerRadius(20)
                            
                      
                            Button(action: {
                                quotecurrentActivityIndex = (quotecurrentActivityIndex + 1) % mood.quote.count
                            }) {
                                Image(systemName: "arrow.trianglehead.2.clockwise")
                                    .frame(width: 50, height: 50)
                                    .background(Color.myblueDark.opacity(0.7))
                                    .foregroundColor(.white)
                                    .cornerRadius(20)
                            }
                            
                        } // HStack
                        
                        Text(mood.quote[quotecurrentActivityIndex])
                            .font(.system(size: 28))
                            .fontDesign(.rounded)
                            .foregroundColor(.black)
                            .multilineTextAlignment(.center)
                            .frame(width: 664)
                            .padding(.horizontal, 30)
                            .padding(.vertical, 30)
                            .background(Color.white.opacity(0.8))
                            .cornerRadius(20)
                    }
                    .padding(.horizontal, 30)
                    
                    
// MARK: - Scientific Info
                    
                    
                    VStack(alignment: .leading){
                        HStack{
                            Text("🔬")
                                .font(.system(size: 60))
                                .frame(width: 90, height: 90)
                                .background(Color.myblueDark.opacity(0.7))
                                .cornerRadius(20)
                            
                        }
                        
                        Text(mood.scientificInfo)
                            .font(.system(size: 28))
                            .fontDesign(.rounded)
                            .foregroundColor(.black)
                            .multilineTextAlignment(.leading)
                            .frame(width: 664)
                            .padding(.horizontal, 30)
                            .padding(.vertical, 30)
                            .background(Color.white.opacity(0.8))
                            .cornerRadius(20)
                    }
                    .padding(.horizontal, 30)
                    
                    
// MARK: - Indoor Activities
                    
                    
                    VStack(alignment: .leading){
                        HStack(alignment: .bottom){
                            Text("🏠")
                                .font(.system(size: 60))
                                .frame(width: 90, height: 90)
                                .background(Color.myblueDark.opacity(0.7))
                                .cornerRadius(20)
                               
                            
                            Button(action: {
                                indoorcurrentActivityIndex = (indoorcurrentActivityIndex + 1) % mood.indoorActivities.count
                            }) {
                                Image(systemName: "arrow.trianglehead.2.clockwise")
                                    .frame(width: 50, height: 50)
                                    .background(Color.myblueDark.opacity(0.7))
                                    .foregroundColor(.white)
                                    .cornerRadius(20)
                            }
                        } // HStack
                        
                        Text(mood.indoorActivities[indoorcurrentActivityIndex])
                            .font(.system(size: 28))
                            .fontDesign(.rounded)
                            .foregroundColor(.black)
                            .multilineTextAlignment(.leading)
                            .frame(width: 664)
                            .padding(.horizontal, 30)
                            .padding(.vertical, 30)
                            .background(Color.white.opacity(0.8))
                            .cornerRadius(20)
                    }
                    .padding(.horizontal, 30)
                    
                    
// MARK: - Outdoor Activities
                    
                    
                    VStack(alignment: .leading){
                        HStack(alignment: .bottom){
                            Text("🏕️")
                                .font(.system(size: 60))
                                .frame(width: 90, height: 90)
                                .background(Color.myblueDark.opacity(0.7))
                                .cornerRadius(20)
                            
                            
                            Button(action: {
                                outdoorcurrentActivityIndex = (outdoorcurrentActivityIndex + 1) % mood.outdoorActivities.count
                            }) {
                                Image(systemName: "arrow.trianglehead.2.clockwise")
                                    .frame(width: 50, height: 50)
                                    .background(Color.myblueDark.opacity(0.7))
                                    .foregroundColor(.white)
                                    .cornerRadius(20)
                            }
                        } // HStack
                        
                        Text(mood.outdoorActivities[outdoorcurrentActivityIndex])
                            .font(.system(size: 28))
                            .fontDesign(.rounded)
                            .foregroundColor(.black)
                            .multilineTextAlignment(.leading)
                            .frame(width: 664)
                            .padding(.horizontal, 30)
                            .padding(.vertical, 30)
                            .background(Color.white.opacity(0.8))
                            .cornerRadius(20)
                        
                    }
                    .padding(.horizontal, 30)
                    
                    
// MARK: - Music
                    
                    
                    VStack(alignment: .leading){
                        HStack(alignment: .bottom){
                            if mood.music != nil {
                                Text("🎸")
                                    .font(.system(size: 60))
                                    .frame(width: 90, height: 90)
                                    .background(Color.myblueDark.opacity(0.7))
                                    .cornerRadius(20)
                            }
                        }
                        
                        if mood.music != nil {
                            Text(mood.music!)
                                .font(.system(size: 28))
                                .fontDesign(.rounded)
                                .foregroundColor(.black)
                                .multilineTextAlignment(.leading)
                                .frame(width: 664)
                                .padding(.horizontal, 30)
                                .padding(.vertical, 30)
                                .background(Color.white.opacity(0.8))
                                .cornerRadius(20)
                        }
                    }
                    
                    
// MARK: - Extra Advices
                    
                    
                    VStack(alignment: .leading){
                        HStack(alignment: .bottom){
                            if mood.extraAdvices != nil {
                                Text("✅")
                                    .font(.system(size: 50))
                                    .frame(width: 90, height: 90)
                                    .background(Color.myblueDark.opacity(0.7))
                                    .cornerRadius(20)
                            }
                        }
                        
                        if mood.extraAdvices != nil {
                            Text(mood.extraAdvices!)
                                .font(.system(size: 28))
                                .fontDesign(.rounded)
                                .foregroundColor(.black)
                                .multilineTextAlignment(.leading)
                                .frame(width: 664)
                                .padding(.horizontal, 30)
                                .padding(.vertical, 30)
                                .background(Color.white.opacity(0.8))
                                .cornerRadius(20)
                        }
                    }
                    
                    
                    Button(action: {
                        showChallengeScreenPopUp = true
                    }){
                        Text("Get a Challenge")
                            .font(.system(size: 35))
                            .fontWeight(.semibold)
                            .fontDesign(.rounded)
                            .frame(width: 720, height: 80)
                            .background(Color.myblueDark)
                            .foregroundColor(.white)
                            .cornerRadius(20)
                    }
                    
                    
                } // General VStack
                .padding(20)
                .navigationTitle(mood.name)
                
                
            } // ScrollView
            .scrollIndicators(.hidden)
            
            Color.black.opacity(showChallengeScreenPopUp ? 0.5 : 0)
                    .ignoresSafeArea()
                    .onTapGesture {
                        showChallengeScreenPopUp = false
                    }
            
            if showChallengeScreenPopUp {
                    ZStack {
                    
                    RoundedRectangle(cornerRadius: 20)
                                    .fill(Color.white)
                                    .frame(width: 600, height: 500)
                                    .shadow(radius: 10)
                    
                    VStack{
     
                            Button(action: {
                                showChallengeScreenPopUp = false
                            }){
                                Image(systemName: "xmark.circle.fill")
                                    .padding(.top, 10)
                                    .font(.system(size: 50))
                                    .foregroundColor(.myblue)
                                    
                            }
                            .padding()
                            .offset(x: 250, y: -7)
                            
                        
              Spacer()
                        
                        Text(challenges.challenges[challengecurrentActivityIndex])
                            .font(.system(size: 40))
                            .fontDesign(.rounded)
                            .fontWeight(.medium)
                            .padding(.horizontal, 40)
                            .multilineTextAlignment(.center)
                        
              Spacer()
                        
                            Button(action: {
                                challengecurrentActivityIndex = (challengecurrentActivityIndex + 1) % challenges.challenges.count
                            }){
                                Text("Change")
                                    .padding()
                                    .font(.system(size: 35))
                                    .fontWeight(.semibold)
                                    .fontDesign(.rounded)
                                    .frame(width: 500, height: 80)
                                    .background(Color.myblueDark)
                                    .foregroundColor(.white)
                                    .cornerRadius(20)
                                
                            }
                            .padding(.vertical, 30)
                        
                    }
                    
                } // Pop up ZStack
                .frame(maxWidth: 600, maxHeight: 500)
                .padding()
                
                
                
                } // Pop up
            
            
                
        } // ZStack
        
        
                
       
    } // Body
}


#Preview {
    if #available(iOS 16.1, *) {
        MoodDetailPage(challengecurrentActivityIndex: 0, mood: moodHappy)
    }
}
