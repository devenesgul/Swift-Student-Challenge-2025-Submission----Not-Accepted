

import Foundation
import SwiftUICore

struct MoodDetailInfo: Identifiable {
    var id = UUID()
    
    let name: String
    let emoji: String
    let quote: [String]
    let scientificInfo: String
    let indoorActivities: [String]
    let outdoorActivities: [String]
    var music: String?
    var extraAdvices: String?
    
   
    
}

let allMoodsArray: [MoodDetailInfo] = [moodHappy, moodSad, moodAngry, moodEnergetic, moodAnxious, moodTired, moodBored]

// MARK: - Happy

let moodHappy = MoodDetailInfo(
    
    name: "Happy",
    emoji: "😊",
    
    
    quote: ["\"The only joy in the world is to begin.\"",
            "\"Happiness depends upon ourselves.\"",
            "\"For every minute you are angry, you lose sixty seconds of happiness.\""],
    
    scientificInfo: "Happiness stimulates the release of dopamine, serotonin, and endorphins in the brain, enhancing mood, reducing stress, and contributing to improved mental health and emotional stability.",
    
    indoorActivities: ["Meditation: Try a short 10-minute meditation session to center yourself and increase your sense of calm and happiness.",
                       "Journaling: Write down 3 things you’re grateful for today. This practice has been shown to increase happiness over time.",
                       "Creative Expression: Try drawing, painting, or writing a poem to express your feelings. Creative activities are linked to increased mood and happiness.",
                       "Cook a New Recipe: Experiment with cooking a fun, easy recipe. The process of creating something new can be quite fulfilling.",
                       "Watch a Feel-Good Movie or TV Show: Put on a movie or a show that makes you laugh and feel light-hearted."
                      ],
    
    outdoorActivities: ["Take a Nature Walk: Walk in the park or take a hike. Being in nature and breathing fresh air has been shown to reduce stress and improve your mood.",
        "Play a Sport: Engage in an activity like running, cycling, or playing a game of basketball. Physical exercise is proven to boost happiness levels.",
        "Volunteer for a Local Charity Event: Helping others in your community can create a sense of purpose and significantly boost your own well-being.",
        "Have a Picnic with Friends or Family: Enjoy a relaxed time outdoors with loved ones, savoring good food and positive conversation.",
        "Visit Your Favorite Place: Take a trip to a spot that always brings you joy, whether it's a quiet park, a coffee shop, or a scenic viewpoint."
                       ],
    
    music: "Listening to upbeat music has an instant effect on happiness. Create a playlist of your favorite feel-good songs and enjoy them during the day.")

// MARK: - Energetic

let moodEnergetic = MoodDetailInfo(
    
    name: "Energetic",
    emoji: "⚡️",
    
    quote: ["\"Energy is contagious, either you get infected or you infect others.\"",
            "\"The best way to predict the future is to create it.\"",
            "\"Success is the sum of small efforts, repeated day in and day out.\""
           ],
    
    scientificInfo: "Studies show that physical activity increases dopamine and serotonin levels, which boosts energy and motivation. Even a short burst of exercise can improve mood and focus, making it easier to tackle challenges.",
    
    indoorActivities: ["Try a New Workout Routine: Push your body by trying something new like yoga, pilates, or a HIIT workout. It’ll challenge you in ways that spark new energy!",
                       "Creative DIY Projects: Put your energy into crafting something meaningful, whether it's painting, knitting, or building something from scratch. Use supplies you have at home to create something you can be proud of.",
                       "Start a Personal Challenge: Take on a self-imposed challenge, like trying to beat your previous record in a workout or completing a puzzle in under an hour.",
                       "Plan Your Week: Organize your time to channel your energy into productive tasks. Use planners, calendars, or digital apps to plan the upcoming days.",
                       "Learn a New Skill: Use your energy to learn something new that you’ve always wanted to try, such as playing an instrument, drawing, or cooking a new dish."
                      ],
    
    outdoorActivities: ["Take a Nature Walk or Hike: Energize your body by exploring the great outdoors. Nature is both physically refreshing and mentally rejuvenating.",
                        "Go for a Bike Ride or Skating: Pedal around your neighborhood or a nearby park. It’s a great way to feel energized and explore the world around you.",
                        "Organize a Game with Friends: Gather friends for a fun and active outdoor game like tag, frisbee, or soccer. It’s a great way to boost both energy and mood. Organize a mini soccer match in your backyard or at the local park.",
                        "Explore a New Location: Take advantage of your energy by exploring an unknown or rarely visited place. Go to a new park, beach, or even a town nearby."
                       ],
    
    extraAdvices: """
Channel Your Energy into a Productive Hobby 🎨

Use your high energy to cultivate a new skill or hobby. Whether it’s starting a fitness regimen or learning how to play a new instrument, this is the time to invest in something that will grow with you. The more you challenge yourself, the more rewarding your energy will feel.
    
Prioritize Your Tasks 📋

With so much energy, it's easy to get distracted by too many ideas. Try creating a list of tasks and rank them in order of importance to maximize your productivity.
""")

// MARK: - Angry

let moodAngry = MoodDetailInfo(
    
    name: "Angry",
    emoji: "😡",
    
    quote: ["\"For every minute you remain angry, you give up sixty seconds of peace.\"",
            "\"Holding onto anger is like drinking poison and expecting the other person to die.\"",
            "\"Speak when you are angry and you will make the best speech you will ever regret.\""
           ],
    
    scientificInfo: "Anger triggers the amygdala, leading to a fight-or-flight response. Deep breathing and mindfulness can reduce cortisol levels, helping restore emotional balance. Engaging in physical activities also helps release pent-up frustration.",
    
    indoorActivities: ["Deep Breathing Exercises: Try the 4-7-8 technique to calm your mind.",
                       "Listen to Soothing Music: Classical or nature sounds can reduce stress levels.",
                       "Write It Out: Journaling helps release anger in a constructive way.",
                       "Do a Puzzle or Brain Game: Redirects focus and promotes mindfulness.",
                       "Punch a Pillow: A safe way to physically release frustration."
                      ],
    
    outdoorActivities: ["Go for a Run or Walk: Physical movement helps burn off excess energy.",
                        "Hit the Gym: Lifting weights or boxing can be therapeutic.",
                        "Scream in an Open Space: Releasing emotions in nature can be liberating.",
                        "Spend Time in Nature: Green spaces help lower stress and cortisol.",
                        "Visit a Favorite Quiet Spot: A calming environment can ease frustration."
                       ],
    
    music: "Slow-tempo, deep rhythm music can help regulate your nervous system. Low-frequency instrumental sounds or nature ambience may stabilize your heart rate.")

// MARK: - Tired

let moodTired = MoodDetailInfo(
    
    name: "Tired",
    emoji: "😴",
    
    quote: ["\"Rest when you’re weary. Refresh and renew yourself, your body, your mind, your spirit. Then get back to work.\"",
            "\"Almost everything will work again if you unplug it for a few minutes, including you.\"",
            "\"The best bridge between despair and hope is a good night’s sleep.\""
           ],
    
    scientificInfo: "Fatigue is often caused by poor sleep, dehydration, or mental overload. A 10-20 minute power nap improves cognitive function, while exposure to natural light regulates circadian rhythms. Hydration, light stretching, and controlled breathing can enhance alertness without the need for caffeine.",
    
    indoorActivities: ["Power Nap: A short nap (10-20 min) can restore energy without causing grogginess.",
                       "Stretch or Do Yoga: Gentle movements reduce tension and improve circulation.",
                       "Drink Herbal Tea: Chamomile or peppermint tea promotes relaxation.",
                       "Listen to Soft Music or White Noise: A calming environment helps reset your mind.",
                       "Try Aromatherapy: Lavender, eucalyptus, or sandalwood scents can relax the nervous system."
                      ],
    
    outdoorActivities: ["Take a Leisurely Walk: Fresh air and sunlight improve mood and energy levels.",
                        "Sit in a Park or Garden: Being in nature has a calming effect and refreshes the mind.",
                        "Do Light Physical Activity: A short bike ride or slow-paced movement can help.",
                        "Practice Grounding: Walk barefoot on grass or touch trees to connect with nature.",
                        "Visit a Quiet Favorite Place: A peaceful environment aids relaxation and recharges energy."
                       ],
    
    music: "Soft-tempo melodies, such as lo-fi or acoustic tunes, support relaxation while boosting focus by stimulating alpha brain waves.",
    
    extraAdvices: """
Fatigue is often linked to shallow breathing. Try these breathing exercises to increase oxygen levels and feel refreshed:

📌 4-7-8 Breathing: Inhale for 4 seconds, hold for 7, and exhale for 8.

📌 Box Breathing: Inhale for 4 seconds, hold for 4, exhale for 4, and hold for another 4.

📌 Diaphragmatic Breathing: Breathe deeply into your belly instead of your chest.
""")

// MARK: - Sad

let moodSad = MoodDetailInfo(
    
    name: "Sad",
    emoji: "😔",
    
    quote: ["\"Tears are words that need to be written.\"",
            "\"Sometimes, we just need to take a deep breath and remind ourselves that everything will be okay.\"",
            "\"Sadness flies away on the wings of time.\""
           ],
    
    scientificInfo: "Sadness is a natural response to loss, disappointment, or stress. Studies show that crying releases oxytocin and endorphins, which act as natural pain relievers and mood boosters. Additionally, engaging in self-compassion activitiesand physical movement can increase serotonin levels, improving emotional well-being.",
    
    indoorActivities: ["Journaling: Writing down your thoughts helps process emotions and gain clarity.",
                       "Watch a Comforting Movie: Choose heartwarming films.",
                       "Listen to Music that Reflects or Lifts Your Mood: Sometimes, sad songs help release emotions, while uplifting songs improve mood.",
                       "Create Something: Painting, crafting, or playing an instrument can be therapeutic.",
                       "Declutter a Small Space: Organizing your environment can bring a sense of control and relief."
                      ],
    
    outdoorActivities: ["Walk in Nature: Exposure to green spaces reduces stress and sadness.",
                        "Sunlight Therapy: Spending 15 minutes in the sun increases vitamin D and boosts serotonin.",
                        "Visit a Cozy Cafe or Bookstore: A change of scenery and a warm drink can be comforting.",
                        "Do a Simple Kindness Act: Helping others (even a small compliment) can increase personal happiness.",
                        "Go Somewhere That Makes You Feel Safe & Happy: This could be a childhood place, a peaceful park, or the seaside."
                       ],
    
    music: "According to resonance theory, listening to music that reflects your feelings can be soothing and validating.",
    
    extraAdvices: """
Taking care of yourself when feeling sad is essential. Here are some gentle self-care actions:

⭐️ Take a Warm Bath: Heat relaxes muscles and soothes the mind.

⭐️ Give Yourself a Hug or Wrap in a Blanket: Physical comfort can be calming.

⭐️ Talk to a Friend or Write a Letter to Yourself: Expressing emotions in any form helps.

⭐️ Do Breathing Exercises: Slow, deep breaths activate the parasympathetic nervous system, reducing stress.
""")

// MARK: - Anxious

let moodAnxious = MoodDetailInfo(
    
    name: "Anxious",
    emoji: "😰",
    
    quote: ["\"You don’t have to control your thoughts. You just have to stop letting them control you.\"",
            "\"Nothing diminishes anxiety faster than action.\"",
            "\"Almost everything will work again if you unplug it for a few minutes, including you.\""
           ],
    
    scientificInfo: "Anxiety is the body's natural response to stress, activating the fight-or-flight response. However, prolonged anxiety can overstimulate the amygdala, increasing stress hormones like cortisol. Studies show that controlled breathing (4-7-8 technique), mindfulness, and physical activity help regulate the nervous system and promote a sense of calm.",
    
    indoorActivities: ["5-4-3-2-1 Grounding Technique: Identify 5 things you can see, 4 you can touch, 3 you can hear, 2 you can smell, and 1 you can taste.",
                       "Deep Breathing Exercises: Try box breathing (inhale for 4 sec, hold for 4 sec, exhale for 4 sec).",
                       "Organize a Small Space: Cleaning and decluttering create a sense of order.",
                       "Write Down Your Worries & Challenge Them: Journaling can help you gain perspective.",
                       "Do a Gentle Yoga or Stretching Routine: Movement relieves muscle tension linked to anxiety."
                      ],
    
    outdoorActivities: ["Take a Slow, Mindful Walk: Focus on each step, the breeze, and sounds around you.",
                        "Sit in a Park & Observe Nature: Green environments lower cortisol levels.",
                        "Go to a Quiet Place with Fresh Air: A rooftop, balcony, or garden can offer relief.",
                        "Move Your Body: A short jog, a bike ride, or simple stretches outside help release tension.",
                        "Visit a Familiar Comforting Place: A bookstore, coffee shop, or a peaceful bench in the park."
                       ],
    
    music: "Rhythmic melodies around 60 bpm can regulate breathing and calm the nervous system. Binaural beats may also help reduce stress levels.",
    
    extraAdvices: """
Quick Anxiety-Relief Hacks

☀️ Splash Cold Water on Your Face: Activates the vagus nerve, helping calm your system.

☀️ Hold an Ice Cube or Focus on a Sensation: Shifts focus from worry to present moment.

☀️ Humming or Singing Softly: Stimulates the vagus nerve, reducing stress.

☀️ Limit Caffeine Intake: Stimulants can worsen anxiety symptoms.

☀️ Repeat a Comforting Mantra: "I am safe. I am in control. This feeling will pass."
""")

// MARK: - Bored

let moodBored = MoodDetailInfo(
    
    name: "Bored",
    emoji: "😒",
    
    
    quote: ["\"Boredom always precedes a period of great creativity.\"",
            "\"The cure for boredom is curiosity. There is no cure for curiosity.\"",
            "\"Boredom is the feeling that everything is a waste of time; serenity, that nothing is.\""
           ],
    
    scientificInfo: "Boredom occurs when the dopamine levels in the brain drop, signaling a lack of stimulation. However, studies show that boredom can boost creativity, problem-solving skills, and self-reflection. Engaging in new activities, learning something unfamiliar, or simply allowing the mind to wander can spark innovation and fresh ideas.",
    
    indoorActivities: ["Try a 5-Minute Creativity Challenge: Write a short poem, sketch something, or create a random story.",
                       "Watch a Random TED Talk: Expand your knowledge on a topic you never considered before.",
                       "Rearrange Your Room: Changing your environment can refresh your mindset.",
                       "Learn a New Skill: Try origami, speed reading, or even juggling!",
                       "Play a Mind Game: Solve a Rubik’s cube, play chess, or try a puzzle game."
                      ],
    
    outdoorActivities: ["Explore a New Area in Your City: Visit a street, park, or café you've never been to before.",
                        "Go People-Watching: Sit in a public place and create imaginary backstories for strangers.",
                        "Try a -No Destination- Walk: Pick a random direction and explore for 20 minutes.",
                        "Do a Random Act of Kindness: Compliment a stranger, leave a nice note somewhere, or help someone in need.",
                        "Look for Hidden Art in the City: Search for graffiti, murals, or sculptures you've never noticed before."
                       ],
    
    music: "Upbeat and dynamic rhythms stimulate brain activity. Music that enhances dopamine production can improve motivation and mental engagement.",
    
    extraAdvices: """
Boredom-Busting Challenges

📌 Write a Letter to Your Future Self: Open it a year from now!

📌 Create a Mini Bucket List for the Week: Try new foods, visit new places, or learn fun facts.

📌 Research Random Topics: Read about a random topic and share a fun fact with a friend.

📌 Do a "One-Day Social Media Detox": Disconnect and focus on real-world activities.

📌 Challenge Yourself to 1 Hour Without Screens: Read, doodle, meditate, or organize your space.
""")



struct getAChallenge: Identifiable{
    let id = UUID()
    
    let challenges: [String]
}


